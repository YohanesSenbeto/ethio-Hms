SELECT * FROM HospitalManagementSystem.superAdmin;

SELECT * FROM HospitalManagementSystem.admin;

SELECT * FROM HospitalManagementSystem.patient;

SELECT * FROM HospitalManagementSystem.doctors;
